﻿
namespace PROG6221_POE_TASK_1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.grossmonthlyincome = new System.Windows.Forms.Label();
            this.monthlyincome = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.Price1 = new System.Windows.Forms.Label();
            this.textboxname = new System.Windows.Forms.TextBox();
            this.Textnum = new System.Windows.Forms.TextBox();
            this.textBox = new System.Windows.Forms.TextBox();
            this.textname = new System.Windows.Forms.TextBox();
            this.texttwo = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.totaldeposit1 = new System.Windows.Forms.Label();
            this.interestrate1 = new System.Windows.Forms.Label();
            this.numberofmonths = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboboxone = new System.Windows.Forms.ComboBox();
            this.totalpayment = new System.Windows.Forms.TextBox();
            this.CB1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.PP = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label17 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Black", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(269, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Budget App Menu For Siphiwe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Black", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(285, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(185, 21);
            this.label5.TabIndex = 4;
            this.label5.Text = "Monthly Expenditures";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(152, 89);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(197, 23);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(124, 127);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(183, 23);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(101, 279);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(179, 23);
            this.textBox4.TabIndex = 15;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(124, 308);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 23);
            this.textBox7.TabIndex = 16;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(180, 337);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 23);
            this.textBox8.TabIndex = 17;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(159, 375);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 23);
            this.textBox9.TabIndex = 18;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(124, 404);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(156, 23);
            this.textBox10.TabIndex = 19;
            // 
            // grossmonthlyincome
            // 
            this.grossmonthlyincome.AutoSize = true;
            this.grossmonthlyincome.Location = new System.Drawing.Point(22, 94);
            this.grossmonthlyincome.Name = "grossmonthlyincome";
            this.grossmonthlyincome.Size = new System.Drawing.Size(127, 15);
            this.grossmonthlyincome.TabIndex = 21;
            this.grossmonthlyincome.Text = "Gross monthly income";
            // 
            // monthlyincome
            // 
            this.monthlyincome.AutoSize = true;
            this.monthlyincome.Location = new System.Drawing.Point(22, 135);
            this.monthlyincome.Name = "monthlyincome";
            this.monthlyincome.Size = new System.Drawing.Size(95, 15);
            this.monthlyincome.TabIndex = 22;
            this.monthlyincome.Text = "Monthly income";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "Groceries";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 24;
            this.label6.Text = "water & lights";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 15);
            this.label7.TabIndex = 25;
            this.label7.Text = "Travel cost(including petrol)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 375);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 15);
            this.label8.TabIndex = 26;
            this.label8.Text = "Cellphone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 411);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 27;
            this.label9.Text = "Other expenses";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(384, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 15);
            this.label10.TabIndex = 28;
            this.label10.Text = "Accommadation";
            // 
            // Price1
            // 
            this.Price1.AutoSize = true;
            this.Price1.Location = new System.Drawing.Point(338, 140);
            this.Price1.Name = "Price1";
            this.Price1.Size = new System.Drawing.Size(76, 15);
            this.Price1.TabIndex = 29;
            this.Price1.Text = "Rent amount";
            // 
            // textboxname
            // 
            this.textboxname.Location = new System.Drawing.Point(438, 134);
            this.textboxname.Name = "textboxname";
            this.textboxname.Size = new System.Drawing.Size(100, 23);
            this.textboxname.TabIndex = 30;
            this.textboxname.Visible = false;
            // 
            // Textnum
            // 
            this.Textnum.Location = new System.Drawing.Point(584, 134);
            this.Textnum.Name = "Textnum";
            this.Textnum.Size = new System.Drawing.Size(100, 23);
            this.Textnum.TabIndex = 31;
            this.Textnum.Visible = false;
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(584, 179);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(100, 23);
            this.textBox.TabIndex = 32;
            this.textBox.Visible = false;
            // 
            // textname
            // 
            this.textname.Location = new System.Drawing.Point(584, 220);
            this.textname.Name = "textname";
            this.textname.Size = new System.Drawing.Size(100, 23);
            this.textname.TabIndex = 33;
            this.textname.Visible = false;
            // 
            // texttwo
            // 
            this.texttwo.Location = new System.Drawing.Point(584, 264);
            this.texttwo.Name = "texttwo";
            this.texttwo.Size = new System.Drawing.Size(100, 23);
            this.texttwo.TabIndex = 34;
            this.texttwo.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(691, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(166, 15);
            this.label12.TabIndex = 35;
            this.label12.Text = "Purchase price of the property";
            // 
            // totaldeposit1
            // 
            this.totaldeposit1.AutoSize = true;
            this.totaldeposit1.Location = new System.Drawing.Point(691, 186);
            this.totaldeposit1.Name = "totaldeposit1";
            this.totaldeposit1.Size = new System.Drawing.Size(74, 15);
            this.totaldeposit1.TabIndex = 36;
            this.totaldeposit1.Text = "Total deposit";
            // 
            // interestrate1
            // 
            this.interestrate1.AutoSize = true;
            this.interestrate1.Location = new System.Drawing.Point(691, 227);
            this.interestrate1.Name = "interestrate1";
            this.interestrate1.Size = new System.Drawing.Size(69, 15);
            this.interestrate1.TabIndex = 37;
            this.interestrate1.Text = "Interest rate";
            // 
            // numberofmonths
            // 
            this.numberofmonths.AutoSize = true;
            this.numberofmonths.Location = new System.Drawing.Point(691, 272);
            this.numberofmonths.Name = "numberofmonths";
            this.numberofmonths.Size = new System.Drawing.Size(155, 15);
            this.numberofmonths.TabIndex = 38;
            this.numberofmonths.Text = "Number of months to repay";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(555, 375);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "Calculations";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboboxone
            // 
            this.comboboxone.FormattingEnabled = true;
            this.comboboxone.Items.AddRange(new object[] {
            "Renting property",
            "Buying properrty"});
            this.comboboxone.Location = new System.Drawing.Point(497, 86);
            this.comboboxone.Name = "comboboxone";
            this.comboboxone.Size = new System.Drawing.Size(121, 23);
            this.comboboxone.TabIndex = 40;
            this.comboboxone.SelectedIndexChanged += new System.EventHandler(this.comboboxone_SelectedIndexChanged);
            // 
            // totalpayment
            // 
            this.totalpayment.Location = new System.Drawing.Point(384, 307);
            this.totalpayment.Name = "totalpayment";
            this.totalpayment.Size = new System.Drawing.Size(100, 23);
            this.totalpayment.TabIndex = 41;
            // 
            // CB1
            // 
            this.CB1.FormattingEnabled = true;
            this.CB1.Items.AddRange(new object[] {
            "Buy a vehicle",
            "Rent a vehicle"});
            this.CB1.Location = new System.Drawing.Point(124, 553);
            this.CB1.Name = "CB1";
            this.CB1.Size = new System.Drawing.Size(121, 23);
            this.CB1.TabIndex = 42;
            this.CB1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 560);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 43;
            this.label2.Text = "Choose";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 614);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 15);
            this.label1.TabIndex = 44;
            this.label1.Text = "Model and make";
            // 
            // PP
            // 
            this.PP.AutoSize = true;
            this.PP.Location = new System.Drawing.Point(15, 645);
            this.PP.Name = "PP";
            this.PP.Size = new System.Drawing.Size(84, 15);
            this.PP.TabIndex = 45;
            this.PP.Text = "Purchase price";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 679);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 15);
            this.label13.TabIndex = 46;
            this.label13.Text = "Total deposit";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 707);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(87, 15);
            this.label14.TabIndex = 47;
            this.label14.Text = "Interest rate(%)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(307, 614);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(165, 15);
            this.label15.TabIndex = 48;
            this.label15.Text = "Estimated insurance premium";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(124, 645);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 23);
            this.textBox5.TabIndex = 50;
            this.textBox5.Visible = false;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(124, 679);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 23);
            this.textBox6.TabIndex = 51;
            this.textBox6.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(124, 709);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 23);
            this.textBox11.TabIndex = 52;
            this.textBox11.Visible = false;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(497, 614);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 23);
            this.textBox12.TabIndex = 53;
            this.textBox12.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(305, 560);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 15);
            this.label16.TabIndex = 54;
            this.label16.Text = "renting a vehicle";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(428, 551);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 23);
            this.textBox13.TabIndex = 55;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(657, 714);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 56;
            this.button2.Text = "Calculations";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(269, 725);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(187, 15);
            this.label17.TabIndex = 57;
            this.label17.Text = "Total monthly cost of buying a car";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(462, 722);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 23);
            this.textBox14.TabIndex = 58;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Nissan Altima",
            "Toyota Corona",
            "Toyota Prius",
            "Honda Pilot"});
            this.comboBox1.Location = new System.Drawing.Point(124, 614);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 23);
            this.comboBox1.TabIndex = 59;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(269, 687);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 15);
            this.label11.TabIndex = 60;
            this.label11.Text = "Total expenses cost";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(384, 687);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 61;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 749);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.PP);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CB1);
            this.Controls.Add(this.totalpayment);
            this.Controls.Add(this.comboboxone);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.numberofmonths);
            this.Controls.Add(this.interestrate1);
            this.Controls.Add(this.totaldeposit1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.texttwo);
            this.Controls.Add(this.textname);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.Textnum);
            this.Controls.Add(this.textboxname);
            this.Controls.Add(this.Price1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.monthlyincome);
            this.Controls.Add(this.grossmonthlyincome);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label monthlyincome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label Price1;
        private System.Windows.Forms.TextBox textboxname;
        private System.Windows.Forms.TextBox Textnum;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.TextBox textname;
        private System.Windows.Forms.TextBox texttwo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label totaldeposit1;
        private System.Windows.Forms.Label interestrate1;
        private System.Windows.Forms.Label numberofmonths;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboboxone;
        private System.Windows.Forms.Label grossmonthlyincome;
        private System.Windows.Forms.TextBox totalpayment;
        private System.Windows.Forms.ComboBox CB1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label PP;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox1;
    }
}

