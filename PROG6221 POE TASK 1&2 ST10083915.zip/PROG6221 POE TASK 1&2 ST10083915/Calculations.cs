﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PROG6221_POE_TASK_1
{
    class Calculations
    {
    }
}
